default[:cloudpassage_linux][:daemon_key] = "abc123abc123abc123abc123abc123ab"
default[:cloudpassage_linux][:tag] = "ChefRocks"
