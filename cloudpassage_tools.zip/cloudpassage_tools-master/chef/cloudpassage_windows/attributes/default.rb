default[:cloudpassage_windows][:halo_exe] = "cphalo-2.7.8-win64.exe"
default[:cloudpassage_windows][:daemon_key] = "abc123abc123abc123abc123abc123ab"
default[:cloudpassage_windows][:tag] = "windowsRocks"
